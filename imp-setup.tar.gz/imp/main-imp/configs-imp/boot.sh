#!/bin/bash
IMP=/opt/retropie/configs/imp
IMPSettings=$IMP/settings
IMPPlaylist=$IMP/playlist

# musicDIR=$(readlink ~/RetroPie/retropiemenu/imp/music)
musicDIR=~/RetroPie/retropiemenu/imp/music
musicROMS=~/RetroPie/roms/music
BGMdir="$musicDIR/bgm"
BGMa="$musicDIR/bgm/A-SIDE"
BGMb="$musicDIR/bgm/B-SIDE"

# Create Music Directories if not found
if [ ! -d "$musicDIR" ]; then mkdir "$musicDIR"; fi
if [ ! -d "$musicROMS" ]; then ln -s "$musicDIR" "$musicROMS"; fi
if [ ! -d "$BGMdir" ]; then mkdir "$BGMdir"; fi
if [ ! -d "$BGMa" ]; then mkdir "$BGMa"; fi
if [ ! -d "$BGMb" ]; then mkdir "$BGMb"; fi

# Start HTTP Server if flag 1 - Used at Startup
if [ $(cat $IMPSettings/http-server.flag) == "1" ]; then sleep 5 && bash "$IMP/httpon.sh"; fi &

# Exit if music startup flag 0
if [ $(cat $IMPSettings/music-startup.flag) == "0" ]; then exit 0; fi

# If any BGM flags 1 - Clear init playlist
if [[ $(cat $IMPSettings/a-side.flag) == "1" || $(cat $IMPSettings/b-side.flag) == "1" ]]; then
	cat /dev/null > $IMPPlaylist/init
fi

# Overwrite init playlist if BGM A-SIDE flag 1
if [ $(cat $IMPSettings/a-side.flag) == "1" ]; then
	# Output A-SIDE to init playlist
	find $BGMa -iname "*.mp3" > $IMPPlaylist/init
	cat $IMPPlaylist/init | sort -n > $IMPPlaylist/abc
	cat $IMPPlaylist/init | sort --random-sort > $IMPPlaylist/shuffle
fi

# Append init playlist if BGM B-SIDE flag 1
if [ $(cat $IMPSettings/b-side.flag) == "1" ]; then
	# Append B-SIDE to init playlist
	find $BGMb -iname "*.mp3" >> $IMPPlaylist/init
	cat $IMPPlaylist/init | sort -n > $IMPPlaylist/abc
	cat $IMPPlaylist/init | sort --random-sort > $IMPPlaylist/shuffle
fi

# Start the Music Player Loop Script
bash "$IMP/play.sh" &
exit 0
