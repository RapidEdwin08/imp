#!/usr/bin/env bash
echo ""
echo "Switching default boot to Emulation Station and rebooting"
echo ""
sleep 5
echo "#/home/pi/scripts/themerandom.sh" > /opt/retropie/configs/all/autostart.sh
# echo "while pgrep omxplayer >/dev/null; do sleep 1; done" >> /opt/retropie/configs/all/autostart.sh
# echo "(sleep 10; mpg123 -Z /home/pi/RetroPie/roms/music/*.mp3 >/dev/null 2>&1) &" >> /opt/retropie/configs/all/autostart.sh
echo 'while pgrep omxplayer >/dev/null; do sleep $(cat /opt/retropie/configs/imp/settings/delay-startup.flag); done && bash /opt/retropie/configs/imp/boot.sh > /dev/null 2>&1 &' >> /opt/retropie/configs/all/autostart.sh
echo "emulationstation #auto" >> /opt/retropie/configs/all/autostart.sh 
# disable_dir="/home/pi/RetroPie/roms/music_disable"
# enable_dir="/home/pi/RetroPie/roms/music"

# if [[ -d "$disable_dir" ]]; then
#  mv /home/pi/RetroPie/roms/music_disable /home/pi/RetroPie/roms/music
# fi
sudo reboot