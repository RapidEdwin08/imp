if [ $(cat /opt/retropie/configs/imp/settings/music-over-games.flag) == "0" ]; then bash /opt/retropie/configs/imp/run-onstart.sh; fi
### Access to Selection Menu
## 
# $1 = systemname > openbor
# $3 = full path of ROM-file

if [[ "$1" == "openbor" && "${3##*/}" == "Access Selection Menu.bor" ]]; then
    # pkill runcommand.sh # Maybe needed to prevent first runcommand from being messed up
    bash "/home/pi/RetroPie/roms/ports/OpenBOR - Beats of Rage Engine Selection.sh"
fi

##
### Access to Selection Menu

echo "$1;$3" > /tmp/lastplayed
/home/pi/.attract/scripts/amlastplayed.sh

enablevideolaunch="true"
if [[ $enablevideolaunch == "true" ]]; then
 # Extract file name from called ROM
 gname="$(basename "$3")"
 # build path to file and remove extension from ROM to add mp4 extension
 # $HOME variable will help users that are not stick to raspberry ;)
 ifgame="$HOME/RetroPie/videoloadingscreens/$1/${gname%.*}.mp4"
 ifsystem="$HOME/RetroPie/videoloadingscreens/$1.mp4"
 default="$HOME/RetroPie/videoloadingscreens/default.mp4"

 # If condition to check filename with -f switch, f means regular file
 if [[ -f $ifgame ]]; then
     omxplayer "$ifgame" > /dev/null 2>&1
 elif [[ -f $ifsystem ]]; then
      omxplayer "$ifsystem" > /dev/null 2>&1
 elif [[ -f $default ]]; then
    omxplayer "$default" > /dev/null 2>&1
 fi
fi
