while pgrep omxplayer >/dev/null; do sleep $(cat /opt/retropie/configs/imp/settings/delay-startup.flag); done && bash /opt/retropie/configs/imp/boot.sh > /dev/null 2>&1 &
emulationstation #auto
