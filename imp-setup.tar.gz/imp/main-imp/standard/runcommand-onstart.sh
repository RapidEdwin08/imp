if [ $(cat /opt/retropie/configs/imp/settings/music-over-games.flag) == "0" ]; then bash /opt/retropie/configs/imp/run-onstart.sh; fi
