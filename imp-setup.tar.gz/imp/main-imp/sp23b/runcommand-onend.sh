#!/bin/sh
if [ ! $(cat /opt/retropie/configs/imp/settings/music-switch.flag) == "0" ] && [ $(cat /opt/retropie/configs/imp/settings/music-over-games.flag) == "0" ]; then bash /opt/retropie/configs/imp/run-onend.sh; fi &
sudo killall xboxdrv > /dev/null 2>&1
sudo killall pcsx
sudo killall xboxdrv
sudo killall omxplayer
