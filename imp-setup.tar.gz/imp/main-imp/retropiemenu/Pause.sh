#!/bin/bash
IMP=/opt/retropie/configs/imp
IMPSettings=$IMP/settings
IMPPlaylist=$IMP/playlist
httpDIR=$(cat $IMPPlaylist/current-track | grep -q 'Directory: http:' ; echo $?)

# Stop if HTTP Stream - Pause if else
if [ "$httpDIR" == '0' ]; then
	echo "0" > $IMPSettings/music-switch.flag
	bash "$IMP/stop.sh" 0 > /dev/null 2>&1
else
	echo "0" > $IMPSettings/music-switch.flag
	echo "1" > $IMPSettings/pause.flag
	pkill -STOP mpg123 > /dev/null 2>&1
fi

exit 0
