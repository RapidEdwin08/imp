#!/bin/bash
IMP=/opt/retropie/configs/imp
IMPSettings=$IMP/settings
IMPPlaylist=$IMP/playlist

if [[ $(cat $IMPSettings/infinite.flag) == "1" ]]; then
	# Turning INFINITE REPEAT Off
	echo "0" > $IMPSettings/infinite.flag
	if [[ $(cat $IMPSettings/music-switch.flag) == "1" || $(cat $IMPSettings/pause.flag) == "1" ]]; then
		# Stop mpg123loop with continue parameter
		bash "$IMP/stop.sh" continue > /dev/null 2>&1
		bash "$IMP/play.sh" &
		exit 0
	fi
fi

tput reset
exit 0
