#!/bin/bash
IMP=/opt/retropie/configs/imp
IMPSettings=$IMP/settings
IMPPlaylist=$IMP/playlist

# Swap Icons of Limited Features in LITE Mode
rm ~/RetroPie/retropiemenu/icons/impprevious.png
cp ~/RetroPie/retropiemenu/icons/impprevious0n.png ~/RetroPie/retropiemenu/icons/impprevious.png

if [[ $(cat $IMPSettings/lite.flag) == "1" ]]; then
	# Turning LITE MODE Off
	echo "0" > $IMPSettings/lite.flag
	if [[ $(cat $IMPSettings/music-switch.flag) == "1" || $(cat $IMPSettings/pause.flag) == "1" ]]; then
		# Stop mpg123loop with continue parameter
		bash "$IMP/stop.sh" continue > /dev/null 2>&1
		bash "$IMP/play.sh" &
		exit 0
	fi
fi

tput reset
exit 0
