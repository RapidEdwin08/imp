#!/bin/bash

installFLAG=$1
versionIMP=2021.10b
IMP=/opt/retropie/configs/imp
IMPSettings=$IMP/settings
IMPPlaylist=$IMP/playlist
IMPMenuRP=~/RetroPie/retropiemenu/imp
musicDIR=~/RetroPie/retropiemenu/imp/music
musicROMS=~/RetroPie/roms/music
musicROMSdisable=~/RetroPie/roms/music_disable
BGMdir="$musicDIR/bgm"
BGMa="$musicDIR/bgm/A-SIDE"
BGMb="$musicDIR/bgm/B-SIDE"

impLOGO=$(
echo "                               _-+-_                    "
echo "                              '#*=*#-                  "
echo "                         ^....-|:^:|:-../:^            "
echo "                         '-+++#::_::#+++-''            "
echo "                           ':--.-:-----::---:-            "
echo "                       '::.   -.------   .-:           "
echo "                        :-   ':------:. '::.           "
echo "                        =-'  .::-..-::-  ='            "
echo "                             .::-.'-:--                "
echo "                             '---. .-:'                "
echo "              Integrated      '::-'..-'      by     "
echo "              Music            .-- .--       RapidEdwin "
echo "              Player          .:-:.'''       v$versionIMP  "
echo "        ------------------------------------------------------- "
)

impFILEREF=$(
echo
echo "                         # FILE REFERENCES #"
echo "                             ~/.bashrc"
echo "                /etc/emulationstation/es_systems.cfg"
echo "             /opt/retropie/configs/all [retropiemenu.sh]"
echo "       [autostart.sh runcommand-onstart.sh runcommand-onend.sh]"
)

CUSTOMimpFILEREF=$(
echo
echo "                     # CUSTOM INSTALLATION FILES #"
# echo "                           ./custom-imp/"
echo "                      ./custom-imp/autostart.sh"
echo "                   ./custom-imp/runcommand-onend.sh"
echo "                  ./custom-imp/runcommand-onstart.sh"
echo "                  # MODIFY AS NEEDED BEFORE INSTALL #"
)

impFINISHREF=$(
echo
echo "                       # MUSIC DIRECTORIES #"
echo "                    $musicROMS"
echo "              $musicROMS/bgm/A-SIDE"
echo "              $musicROMS/bgm/B-SIDE"
echo
# echo "           /etc/emulationstation/es_systems.cfg"
# echo '         [.rp .sh .mp3 .MP3 .pls .PLS .m3u .M3U]'
# echo '   [bash /opt/retropie/configs/all/retropiemenu.sh %ROM%]'
echo
)


IMPstandard="[STANDARD] Default RetroPie/ES"
IMPsupremezero="[SUPREME] Arcade 0nly Build V2 (PiZero 20180827)"
IMPsupremepro23b="[SUPREME] Pro (Pi2/3/B+ 20200509)"
IMPsupremeunified3ab="[SUPREME] Unified (Pi3A/B/B+ 20190514)"
IMPsupremeduo4="[SUPREME] Duo (Unofficial) (Pi4B 20200104)"
IMPsupremepro4="[SUPREME] Pro (Pi4 20200401)"
IMPsupremeultrav1="[SUPREME] Ultra V1 (Pi4 20210121)"
IMPmbmbttfpp="[MBM] BTTF PleasureParadise (Pi4 19851026)"
IMPcustom="[???] CUSTOM (Customize Before Install)"

mainMENU()
{
# Check for Internet Connection - internetSTATUS Displayed on Main Menu
wget -q --spider http://google.com
if [ $? -eq 0 ]; then
	internetSTATUS="  Internet Connection: [OK]  "
else
	internetSTATUS="   *INTERNET CONNECTION REQUIRED*   "
	if [ "$installFLAG" == 'offline' ]; then internetSTATUS="Offline-Install-Selected"; fi
fi

# Main Install Menu
tput reset
installTYPE=$(dialog --stdout --no-collapse --title "  $internetSTATUS" \
	--ok-label OK --cancel-label Exit \
	--menu "     Choose Type of Install for Integrated Music Player [IMP]:" 25 75 20 \
	1 "$IMPstandard" \
	2 "$IMPsupremezero" \
	3 "$IMPsupremeunified3ab" \
	4 "$IMPsupremepro23b" \
	5 "$IMPsupremepro4" \
	6 "$IMPsupremeduo4" \
	7 "$IMPsupremeultrav1" \
	8 "$IMPmbmbttfpp" \
	9 "$IMPcustom" \
	10 "Uninstall [IMP]")
tput reset

# If ESC then Exit
if [ "$installTYPE" == '' ]; then exit 0; fi

# Uninstall
if [ "$installTYPE" == '10' ]; then
	selectTYPE="UNINSTALL [IMP]"
	# Confirm Uninstall
	confREMOVE=$(dialog --stdout --no-collapse --title "               UNINSTALL [IMP]               " \
		--ok-label OK --cancel-label Back \
		--menu "                          ? ARE YOU SURE ?             " 25 75 20 \
		1 "><  $selectTYPE  ><" \
		2 "Back to Main Menu")
	# Uninstall Confirmed - Otherwise Back to Main Menu
	if [ "$confREMOVE" == '1' ]; then impUNINSTALL; fi
	mainMENU
fi

# Set installTYPEs to selectTYPEs
if [ "$installTYPE" == '1' ]; then selectTYPE="$IMPstandard"; fi
if [ "$installTYPE" == '2' ]; then selectTYPE="$IMPsupremezero"; fi
if [ "$installTYPE" == '3' ]; then selectTYPE="$IMPsupremeunified3ab"; fi
if [ "$installTYPE" == '4' ]; then selectTYPE="$IMPsupremepro23b"; fi
if [ "$installTYPE" == '5' ]; then selectTYPE="$IMPsupremepro4"; fi
if [ "$installTYPE" == '6' ]; then selectTYPE="$IMPsupremeduo4"; fi
if [ "$installTYPE" == '7' ]; then selectTYPE="$IMPsupremeultrav1"; fi
if [ "$installTYPE" == '8' ]; then selectTYPE="$IMPmbmbttfpp"; fi
if [ "$installTYPE" == '9' ]; then selectTYPE="$IMPcustom"; fi

# Custom Install Files Creation
if [ "$selectTYPE" == "$IMPcustom" ]; then
	# Check for the Most Important Setup Directories and Files [custom-imp/*] - CREATE them if NOT found
	if [ ! -d custom-imp/ ]; then mkdir custom-imp; fi
	if [ ! -f custom-imp/autostart.sh ]; then cp main-imp/standard/autostart.sh custom-imp/autostart.sh; fi
	if [ ! -f custom-imp/runcommand-onend.sh ]; then cp main-imp/standard/runcommand-onend.sh custom-imp/runcommand-onend.sh; fi
	if [ ! -f custom-imp/runcommand-onstart.sh ]; then cp main-imp/standard/runcommand-onstart.sh custom-imp/runcommand-onstart.sh; fi
	
	if [ ! -d custom-imp/templates/ ]; then mkdir custom-imp/templates; fi
	if [ ! -f custom-imp/templates/README ]; then cp main-imp/templates/README custom-imp/templates/README; fi
	if [ ! -f custom-imp/templates/autostart.sh.imp ]; then cp main-imp/standard/autostart.sh custom-imp/templates/autostart.imp; fi
	if [ ! -f custom-imp/templates/runcommand-onend.sh.imp ]; then cp main-imp/standard/runcommand-onend.sh custom-imp/templates/runcommand-onend.imp; fi
	if [ ! -f custom-imp/templates/runcommand-onstart.sh.imp ]; then cp main-imp/standard/runcommand-onstart.sh custom-imp/templates/runcommand-onstart.imp; fi
	
	# 0PTIONAL: Replace [IMP] Menu Scripts that Require Joypad/Keyboard Input to Close
	if [ ! -f custom-imp/templates/Current\ Playlist.no1nput ]; then cp main-imp/spz/Current\ Playlist.sh custom-imp/templates/Current\ Playlist.no1nput; fi
	if [ ! -f custom-imp/templates/Current\ Settings.no1nput ]; then cp main-imp/spz/Current\ Settings.sh custom-imp/templates/Current\ Settings.no1nput; fi
	if [ ! -f custom-imp/templates/HTTP\ Server\ Log.no1nput ]; then cp main-imp/spz/HTTP\ Server\ Log.sh custom-imp/templates/HTTP\ Server\ Log.no1nput; fi
	
	# 0PTIONAL Replace Custom Scripts to be Installed for Attract Mode
	if [ ! -f custom-imp/templates/attractmode.imp ]; then cp main-imp/sp23b/attractmode.sh custom-imp/templates/attractmode.imp; fi
	if [ ! -f custom-imp/templates/emulationstation.imp ]; then cp main-imp/sp23b/emulationstation.sh custom-imp/templates/emulationstation.imp; fi
	
	# 0PTIONAL Replace Custom Scripts to be Installed in: /opt/retropie/configs/all/
	if [ ! -f custom-imp/templates/ES-start.imp ]; then cp main-imp/spuv14/ES-start.sh custom-imp/templates/ES-start.imp; fi
	if [ ! -f custom-imp/templates/Pegasus-start.imp ]; then cp main-imp/spuv14/Pegasus-start.sh custom-imp/templates/Pegasus-start.imp; fi
	
	# Information Custom Install
	dialog --no-collapse --title " * [IMP] CUSTOM SETUP FILES * [custom-imp/*] * PLEASE VERIFY *" --ok-label CONTINUE --msgbox "$impLOGO $CUSTOMimpFILEREF"  25 75
fi

# Check for Internet Connection - If Internet Confirm Install - If No Internet Back to Main Menu
wget -q --spider http://google.com
# if [ $? -eq 0 ]; then# Adding OFFLINE OPTION
if [[ $? -eq 0 || "$installFLAG" == 'offline' ]]; then
	# Confirm Install
	confSTATUS="OK"
	if [ "$installFLAG" == 'offline' ]; then confSTATUS="Offline-Install-Selected"; fi
	confINSTALL=$(dialog --stdout --no-collapse --title "  Internet Connection: [$confSTATUS]  " \
		--ok-label OK --cancel-label Back \
		--menu "                           ? ARE YOU SURE ?             " 25 75 20 \
		1 "INSTALL $selectTYPE" \
		2 "Choose Type of [IMP] Install")
	# Install Confirmed - Otherwise Back to Main Menu
	if [ "$confINSTALL" == '1' ]; then imageCONFIRM; fi
	mainMENU
else
	# No Internet - Back to Main Menu
	dialog --no-collapse --title "               [ERROR]               " --msgbox "   *INTERNET CONNECTION REQUIRED*"  25 75
	mainMENU
fi

tput reset
exit 0
}

imageCONFIRM()
{

# Define Basic Supreme Checks
checkSuPreMe=$(cat ~/.bashrc | grep -q 'SuPreMe' ; echo $?)
SUPREMEcheck=$(cat ~/.bashrc | grep -q 'SUPREME' ; echo $?)

# Skip Unique checks according to selection
if [ "$selectTYPE" == "$IMPcustom" ]; then impINSTALL; fi

# Perform Unique checks according to selection
if [ "$selectTYPE" == "$IMPstandard" ]; then
	if [ ! "$checkSuPreMe" == '0' ] && [ ! "$SUPREMEcheck" == '0' ]; then impINSTALL; fi
fi
if [ "$selectTYPE" == "$IMPsupremezero" ]; then
	if [ "$(cat ~/.bashrc | grep -q 'SuPreMe BuiLd PI 0/2/3/3+ V2' ; echo $?)" == '0' ]; then impINSTALL; fi
fi
if [ "$selectTYPE" == "$IMPsupremeunified3ab" ]; then
	if [ "$(cat ~/.bashrc | grep -q 'SUPREME UNIFIED BY the Supreme team.' ; echo $?)" == '0' ]; then impINSTALL; fi
fi
if [ "$selectTYPE" == "$IMPsupremepro23b" ]; then
	if [ "$(cat ~/.bashrc | grep -q 'SUPREME PRO RPI23b+ By Supreme Team.' ; echo $?)" == '0' ]; then impINSTALL; fi
fi
if [ "$selectTYPE" == "$IMPsupremepro4" ]; then
	if [ "$(cat ~/.bashrc | grep -q 'SUPREME PRO BY THE SUPREME TEAM' ; echo $?)" == '0' ]; then impINSTALL; fi
fi
if [ "$selectTYPE" == "$IMPsupremeduo4" ]; then
	if [ "$(cat ~/.bashrc | grep -q 'SUPREME DUO BY THE SUPREME TEAM AND monkaBlyat.' ; echo $?)" == '0' ]; then impINSTALL; fi
fi
if [ "$selectTYPE" == "$IMPsupremeultrav1" ]; then
	if [ "$(cat ~/.bashrc | grep -q 'SUPREME ULTRA V1 BY THE SUPREME TEAM' ; echo $?)" == '0' ]; then impINSTALL; fi
fi
if [ "$selectTYPE" == "$IMPmbmbttfpp" ]; then
	if [ -d /opt/retropie/configs/all/emulationstation/themes/MB\ Custom\ Back\ to\ the\ Future\ Theme\ 2020-21/ ]; then impINSTALL; fi
fi

confIMAGE=$(dialog --stdout --no-collapse --title "               [ERROR]               " \
	--ok-label OK --cancel-label Back \
	--menu " THIS DOES NOT APPEAR TO BE THE IMAGE YOU SELECTED.  ? ARE YOU SURE ?  Selection: * $selectTYPE *" 25 75 20 \
	1 "Back to Main Menu" \
	2 "><  CONFIRM INSTALL  ><")
# Install Confirmed - Otherwise Back to Main Menu
if [ "$confIMAGE" == '2' ]; then impINSTALL; fi

mainMENU
}

impINSTALL()
{
tput reset

if [ "$selectTYPE" == "$IMPcustom" ]; then
	# Check for the Most Important Setup Directories and Files [custom-imp/*] After Modifications
	if [ ! -d custom-imp/ ]; then
		dialog --no-collapse --title " * [IMP] SETUP FILES MISSING * [custom-imp/*] * PLEASE VERIFY *" --ok-label CONTINUE --msgbox "$impLOGO $impFILEREF"  25 75
		mainMENU
	fi
	if [ ! -f custom-imp/autostart.sh ]; then
		dialog --no-collapse --title " * [IMP] SETUP FILES MISSING * [custom-imp/autostart.sh] * PLEASE VERIFY *" --ok-label CONTINUE --msgbox "$impLOGO $impFILEREF"  25 75
		mainMENU
	fi
	if [ ! -f custom-imp/runcommand-onend.sh ]; then
		dialog --no-collapse --title " * [IMP] SETUP FILES MISSING * [custom-imp/runcommand-onend.sh] * PLEASE VERIFY *" --ok-label CONTINUE --msgbox "$impLOGO $impFILEREF"  25 75
		mainMENU
	fi
	if [ ! -f custom-imp/runcommand-onstart.sh ]; then
		dialog --no-collapse --title " * [IMP] SETUP FILES MISSING * [custom-imp/runcommand-onstart.sh] * PLEASE VERIFY *" --ok-label CONTINUE --msgbox "$impLOGO $impFILEREF"  25 75
		mainMENU
	fi
fi

# Check for the Most Important Setup Directories and Files [main-imp/*]
if [ ! -d main-imp/ ]; then
	dialog --no-collapse --title " * [IMP] SETUP FILES MISSING * [main-imp/*] * PLEASE VERIFY *" --ok-label CONTINUE --msgbox "$impLOGO $impFILEREF"  25 75
	mainMENU
fi

# Check for the Most Important Setup Directories and Files [configs-all/*]
if [ ! -d main-imp/configs-all ]; then
	dialog --no-collapse --title " * [IMP] SETUP FILES MISSING * [main-imp/configs-all/*] * PLEASE VERIFY *" --ok-label CONTINUE --msgbox "$impLOGO $impFILEREF"  25 75
	mainMENU
fi

# Check for the Most Important Setup Directories and Files [configs-all/*]
if [ ! -f main-imp/configs-all/retropiemenu.sh ]; then
	dialog --no-collapse --title " * [IMP] SETUP FILES MISSING * [configs-all/retropiemenu.sh] * PLEASE VERIFY *" --ok-label CONTINUE --msgbox "$impLOGO $impFILEREF"  25 75
	mainMENU
fi

# Check for the Most Important Setup Directories and Files [configs-imp/*]
if [ ! -d main-imp/configs-imp ]; then
	dialog --no-collapse --title " * [IMP] SETUP FILES MISSING * [main-imp/configs-imp/*] * PLEASE VERIFY *" --ok-label CONTINUE --msgbox "$impLOGO $impFILEREF"  25 75
	mainMENU
fi

# Check for the Most Important Setup Directories and Files [gamelist]
if [ ! -f main-imp/gamelist.imp ]; then
	dialog --no-collapse --title " * [IMP] SETUP FILES MISSING * [main-imp/gamelist.imp] * PLEASE VERIFY *" --ok-label CONTINUE --msgbox "$impLOGO $impFILEREF"  25 75
	mainMENU
fi

# Check for the Most Important Setup Directories and Files [configs-imp/*]
if [ ! -d main-imp/standard ]; then
	dialog --no-collapse --title " * [IMP] SETUP FILES MISSING * [main-imp/standard/*] * PLEASE VERIFY *" --ok-label CONTINUE --msgbox "$impLOGO $impFILEREF"  25 75
	mainMENU
fi

# Check for the Most Important Setup Directories and Files [autostart.sh]
if [ ! -f main-imp/standard/autostart.sh ]; then
	dialog --no-collapse --title " * [IMP] SETUP FILES MISSING * [autostart.sh] * PLEASE VERIFY *" --ok-label CONTINUE --msgbox "$impLOGO $impFILEREF"  25 75
	mainMENU
fi

# Check for the Most Important Setup Directories and Files [runcommand-onstart.sh]
if [ ! -f main-imp/standard/runcommand-onstart.sh ]; then
	dialog --no-collapse --title " * [IMP] SETUP FILES MISSING * [runcommand-onstart.sh] * PLEASE VERIFY *" --ok-label CONTINUE --msgbox "$impLOGO $impFILEREF"  25 75
	mainMENU
fi

# Check for the Most Important Setup Directories and Files [runcommand-onend.sh]
if [ ! -f main-imp/standard/runcommand-onend.sh ]; then
	dialog --no-collapse --title " * [IMP] SETUP FILES MISSING * [runcommand-onend.sh] * PLEASE VERIFY *" --ok-label CONTINUE --msgbox "$impLOGO $impFILEREF"  25 75
	mainMENU
fi

# Check if [IMP] already Installed
if [ -d $IMP ]; then
	dialog --no-collapse --title "   * [IMP] INSTALL DETECTED *   *UNINSTALL [IMP] FIRST *" --ok-label CONTINUE --msgbox "$impLOGO $impFILEREF"  25 75
	mainMENU
fi

# Disable 0ther BGMs Indiscriminately
# Backup Various backgroundmusic scripts
if [ -f ~/RetroPie/retropiemenu/backgroundmusic.sh ]; then mv ~/RetroPie/retropiemenu/backgroundmusic.sh ~/RetroPie/retropiemenu/backgroundmusic.sh.b4imp; fi
if [ -f ~/RetroPie/retropiemenu/Audiotools/backgroundmusic.sh ]; then mv ~/RetroPie/retropiemenu/Audiotools/backgroundmusic.sh ~/RetroPie/retropiemenu/Audiotools/backgroundmusic.sh.b4imp; fi
if [ -f ~/RetroPie/retropiemenu/audiotools/backgroundmusic.sh ]; then mv ~/RetroPie/retropiemenu/audiotools/backgroundmusic.sh ~/RetroPie/retropiemenu/audiotools/backgroundmusic.sh.b4imp; fi

# Disable Livewire
if [ ! -f ~/.DisableMusic ]; then touch ~/.DisableMusic; fi

# Disable BGM Naprosnia
sudo pkill -STOP audacious > /dev/null 2>&1
sudo pkill -KILL audacious > /dev/null 2>&1
if [ -f ~/RetroPie-BGM-Player/bgm_system.sh ]; then bash ~/RetroPie-BGM-Player/bgm_system.sh -setsetting bgm_toggle 0; fi
# if [ -f ~/RetroPie/retropiemenu/Audiotools/backgroundmusic.sh ]; then mv ~/RetroPie/retropiemenu/Audiotools/backgroundmusic.sh ~/RetroPie/retropiemenu/Audiotools/backgroundmusic.sh.b4imp 2>/dev/null; fi
if [ -f ~/RetroPie/retropiemenu/RetroPie-BGM-Player.sh ]; then mv ~/RetroPie/retropiemenu/RetroPie-BGM-Player ~/RetroPie/retropiemenu/RetroPie-BGM-Player.sh.b4imp 2>/dev/null; fi

# Disable BGM Rydra
sudo systemctl stop bgm > /dev/null 2>&1
sudo systemctl disable bgm > /dev/null 2>&1
# sudo systemctl daemon-reload > /dev/null 2>&1

# Disable BGM 0fficialPhilcomm
sudo systemctl stop retropie_music > /dev/null 2>&1
sudo systemctl disable retropie_music > /dev/null 2>&1
# sudo systemctl daemon-reload > /dev/null 2>&1

# Final daemon-reload after Disable 0ther BGMs
sudo systemctl daemon-reload > /dev/null 2>&1

# Stop mpg123 if other Scripts had it running
pkill -KILL mpg123  > /dev/null 2>&1

# Install mpg123
# sudo apt-get -y install mpg123 #Adding OFFLINE OPTION
if [ ! "$installFLAG" == 'offline' ]; then sudo apt-get -y install mpg123; fi

# Create Directories
if [ ! -d "$IMP" ]; then mkdir "$IMP"; fi
if [ ! -d "$IMPSettings" ]; then mkdir "$IMPSettings"; fi
if [ ! -d "$IMPPlaylist" ]; then mkdir "$IMPPlaylist"; fi
if [ ! -d "$IMPMenuRP" ]; then mkdir "$IMPMenuRP"; fi

# Put [music] IN [retropiemenu] - ES may not play well with References to Symbolic Links in [retropiemenu]
if [ -d "$musicROMSdisable" ]; then mv "$musicROMSdisable" "$musicROMS"; fi
if [ -d "$musicROMS" ]; then
	if [ ! $(readlink "$musicROMS") == '' ]; then
		# If Symbolic Link - Remove current Link to [roms/music] - Create New Link to [retropiemenu/imp/music/romsLINK]
		romsLINK=$(readlink "$musicROMS" | sed 's/.*\///' )
		if [ ! -d "$musicDIR" ]; then mkdir "$musicDIR"; fi
		if [ ! -d "$musicDIR" ]; then mkdir "$musicDIR/_$romsLINK"; fi
		ln -s $(readlink "$musicROMS") "$musicDIR/_$romsLINK"
		rm "$musicROMS"
	else
		# If NOT Symbolic Link Move [roms/music] Folder to [retropiemenu/imp/music]
		mv "$musicROMS" "$musicDIR"
	fi
fi
# Create the [roms/music] Folder - Symbolic Link [retropiemenu/imp/music] to [roms/music]
if [ ! -d "$musicDIR" ]; then mkdir "$musicDIR"; fi
if [ ! -d "$musicROMS" ]; then ln -s "$musicDIR" "$musicROMS"; fi
# Create Symbolic Links to 0ther Various Music Folders
if [ -d ~/RetroPie/roms/jukebox/mp3 ] && [ ! -d "$musicROMS/_jukebox_mp3" ]; then ln -s ~/RetroPie/roms/jukebox/mp3 "$musicROMS/_jukebox_mp3"; fi
if [ -d ~/bgm ]; then ln -s ~/bgm "$musicDIR/_bgm"; fi
if [ -d ~/RetroPie/backgroundmusic_disable ]; then mv ~/RetroPie/backgroundmusic_disable ~/RetroPie/backgroundmusic; fi
if [ -d ~/RetroPie/backgroundmusic ] && [ ! -d "$musicDIR/_backgroundmusic" ]; then ln -s ~/RetroPie/backgroundmusic "$musicDIR/_backgroundmusic"; fi
# if [ -d ~/.attract/sounds ] && [ ! -d "$musicDIR/_AttractModeSounds" ]; then ln -s ~/.attract/sounds "$musicDIR/_AttractModeSounds"; fi

if [ ! -d "$BGMdir" ]; then mkdir "$BGMdir"; fi
if [ ! -d "$BGMa" ]; then mkdir "$BGMa"; fi
if [ ! -d "$BGMb" ]; then mkdir "$BGMb"; fi
if [ ! -d "$IMPMenuRP/Settings" ]; then mkdir "$IMPMenuRP/Settings"; fi
if [ ! -d "$IMPMenuRP/Settings/BGM Settings" ]; then mkdir "$IMPMenuRP/Settings/BGM Settings"; fi
if [ ! -d "$IMPMenuRP/Settings/Game Settings" ]; then mkdir "$IMPMenuRP/Settings/Game Settings"; fi
if [ ! -d "$IMPMenuRP/Settings/HTTP Server Settings" ]; then mkdir "$IMPMenuRP/Settings/HTTP Server Settings"; fi
if [ ! -d "$IMPMenuRP/Settings/Startup Settings" ]; then mkdir "$IMPMenuRP/Settings/Startup Settings"; fi
if [ ! -d "$IMPMenuRP/Volume" ]; then mkdir "$IMPMenuRP/Volume"; fi

# Copy Files to configs
cp -R main-imp/configs-imp/* "$IMP"
sudo chmod 755 $IMP/*.sh

# Copy Files to retropiemenu
cp -R main-imp/retropiemenu/* $IMPMenuRP

# Backup autostart.sh if not exist already
if [ ! -f /opt/retropie/configs/all/autostart.sh.b4imp ] && [ -f /opt/retropie/configs/all/autostart.sh ]; then
	mv /opt/retropie/configs/all/autostart.sh /opt/retropie/configs/all/autostart.sh.b4imp
fi

# Backup runcommand-onstart if not exist already
if [ ! -f /opt/retropie/configs/all/runcommand-onstart.sh.b4imp ]; then
	mv /opt/retropie/configs/all/runcommand-onstart.sh /opt/retropie/configs/all/runcommand-onstart.sh.b4imp 2>/dev/null
fi

# Backup runcommand-onend if not exist already
if [ ! -f /opt/retropie/configs/all/runcommand-onend.sh.b4imp ]; then
	mv /opt/retropie/configs/all/runcommand-onend.sh /opt/retropie/configs/all/runcommand-onend.sh.b4imp 2>/dev/null
fi

# Backup [.bashrc] if not exist already
if [ ! -f ~/.bashrc.b4imp ]; then cp ~/.bashrc ~/.bashrc.b4imp; fi

# Modify [.bashrc] to Stop [IMP] at ES Exit
bashrcCHECK=$(cat ~/.bashrc | grep -q 'pkill mpg123' ; echo $?)
if [ "$bashrcCHECK" == '0' ]; then
	# Replace [[ $(tty) == "/dev/tty1" ]] && pkill mpg123
	sudo sed -i s+'\[\[ $(tty) == \"/dev/tty1\" \]\] \&\& pkill mpg123'+'\[\[ $(tty) == \"/dev/tty1\" ]] \&\& bash /opt/retropie/configs/imp/stop.sh continue'+ ~/.bashrc
	# Replace pkill mpg123
	sudo sed -i s+'pkill mpg123'+'bash /opt/retropie/configs/imp/stop.sh continue'+ ~/.bashrc
else
	# Replace # RETROPIE PROFILE END
	sudo sed -i s+'# RETROPIE PROFILE END'+'\[\[ $(tty) == "/dev/tty1" \]\] \&\& bash /opt/retropie/configs/imp/stop.sh continue'+ ~/.bashrc
	echo '# RETROPIE PROFILE END' >> ~/.bashrc
fi

# [es_systems.cfg] Modifications to allow [retropiemenu] to run Music files
# ------------ [Default] es_systems.cfg ------------ 
#    <extension>.rp .sh</extension>
#    <command>sudo /home/pi/RetroPie-Setup/retropie_packages.sh retropiemenu launch %ROM% &lt;/dev/tty &gt;/dev/tty</command>

# ------------ [IMP] es_systems.cfg ------------ 
#    <extension>.rp .sh .mp3 .MP3 .pls .PLS .m3u .M3U </extension>
#    <command>bash /opt/retropie/configs/all/retropiemenu.sh %ROM%</command>      

# Create es_systems.cfg ETC
if [ -f /etc/emulationstation/es_systems.cfg ]; then	
	# Backup es_systems.cfg if not exist already
	if [ ! -f /etc/emulationstation/es_systems.cfg.b4imp ]; then sudo cp /etc/emulationstation/es_systems.cfg /etc/emulationstation/es_systems.cfg.b4imp 2>/dev/null; fi
	
	# Replace retropiemenu es_systems.cfg with [IMP]
	sudo sed -i s+'<extension>.rp .sh</extension>'+'<extension>.rp .sh .mp3 .MP3 .pls .PLS .m3u .M3U</extension>'+ /etc/emulationstation/es_systems.cfg
	sudo sed -i s+'<command>sudo /home/pi/RetroPie-Setup/retropie_packages.sh retropiemenu launch %ROM% &lt;/dev/tty &gt;/dev/tty</command>'+'<command>bash /opt/retropie/configs/all/retropiemenu.sh %ROM%</command>'+ /etc/emulationstation/es_systems.cfg
	sudo sed -i s+'<command>sudo ~/RetroPie-Setup/retropie_packages.sh retropiemenu launch %ROM% &lt;/dev/tty &gt;/dev/tty</command>'+'<command>bash /opt/retropie/configs/all/retropiemenu.sh %ROM%</command>'+ /etc/emulationstation/es_systems.cfg
fi

# Create es_systems.cfg OPT
if [ -f /opt/retropie/configs/all/emulationstation/es_systems.cfg ]; then	
	# Backup es_systems.cfg if not exist already
	if [ ! -f /opt/retropie/configs/all/emulationstation/es_systems.cfg.b4imp ]; then sudo cp /opt/retropie/configs/all/emulationstation/es_systems.cfg /opt/retropie/configs/all/emulationstation/es_systems.cfg.b4imp 2>/dev/null; fi
	
	# Replace retropiemenu es_systems.cfg with [IMP]
	sudo sed -i s+'<extension>.rp .sh</extension>'+'<extension>.rp .sh .mp3 .MP3 .pls .PLS .m3u .M3U</extension>'+ /opt/retropie/configs/all/emulationstation/es_systems.cfg
	sudo sed -i s+'<command>sudo /home/pi/RetroPie-Setup/retropie_packages.sh retropiemenu launch %ROM% &lt;/dev/tty &gt;/dev/tty</command>'+'<command>bash /opt/retropie/configs/all/retropiemenu.sh %ROM%</command>'+ /opt/retropie/configs/all/emulationstation/es_systems.cfg
	sudo sed -i s+'<command>sudo ~/RetroPie-Setup/retropie_packages.sh retropiemenu launch %ROM% &lt;/dev/tty &gt;/dev/tty</command>'+'<command>bash /opt/retropie/configs/all/retropiemenu.sh %ROM%</command>'+ /opt/retropie/configs/all/emulationstation/es_systems.cfg
fi

# Create es_systems.cfg  HDDON/HDDOFF BAK
if [ -f /opt/retropie/configs/all/emulationstation/es_systems.cfg.bk ]; then	
	# Backup es_systems.cfg if not exist already
	if [ ! -f /opt/retropie/configs/all/emulationstation/es_systems.cfg.bk.b4imp ]; then sudo cp /opt/retropie/configs/all/emulationstation/es_systems.cfg.bk /opt/retropie/configs/all/emulationstation/es_systems.cfg.bk.b4imp 2>/dev/null; fi
	
	# Replace retropiemenu es_systems.cfg with [IMP]
	sudo sed -i s+'<extension>.rp .sh</extension>'+'<extension>.rp .sh .mp3 .MP3 .pls .PLS .m3u .M3U</extension>'+ /opt/retropie/configs/all/emulationstation/es_systems.cfg.bk
	sudo sed -i s+'<command>sudo /home/pi/RetroPie-Setup/retropie_packages.sh retropiemenu launch %ROM% &lt;/dev/tty &gt;/dev/tty</command>'+'<command>bash /opt/retropie/configs/all/retropiemenu.sh %ROM%</command>'+ /opt/retropie/configs/all/emulationstation/es_systems.cfg.bk
	sudo sed -i s+'<command>sudo ~/RetroPie-Setup/retropie_packages.sh retropiemenu launch %ROM% &lt;/dev/tty &gt;/dev/tty</command>'+'<command>bash /opt/retropie/configs/all/retropiemenu.sh %ROM%</command>'+ /opt/retropie/configs/all/emulationstation/es_systems.cfg.bk
fi

# Create es_systems.cfg HDDOFF
if [ -f ~/RetroPie/scripts/es_systems_HDDOFF.cfg ]; then	
	# Backup es_systems.cfg if not exist already
	if [ ! -f ~/RetroPie/scripts/es_systems_HDDOFF.cfg.b4imp ]; then sudo cp ~/RetroPie/scripts/es_systems_HDDOFF.cfg ~/RetroPie/scripts/es_systems_HDDOFF.cfg.b4imp 2>/dev/null; fi
	
	# Replace retropiemenu es_systems.cfg with [IMP]
	sudo sed -i s+'<extension>.rp .sh</extension>'+'<extension>.rp .sh .mp3 .MP3 .pls .PLS .m3u .M3U</extension>'+ ~/RetroPie/scripts/es_systems_HDDOFF.cfg
	sudo sed -i s+'<command>sudo /home/pi/RetroPie-Setup/retropie_packages.sh retropiemenu launch %ROM% &lt;/dev/tty &gt;/dev/tty</command>'+'<command>bash /opt/retropie/configs/all/retropiemenu.sh %ROM%</command>'+ ~/RetroPie/scripts/es_systems_HDDOFF.cfg
	sudo sed -i s+'<command>sudo ~/RetroPie-Setup/retropie_packages.sh retropiemenu launch %ROM% &lt;/dev/tty &gt;/dev/tty</command>'+'<command>bash /opt/retropie/configs/all/retropiemenu.sh %ROM%</command>'+ ~/RetroPie/scripts/es_systems_HDDOFF.cfg
fi

# Create es_systems.cfg  HDDON
if [ -f ~/RetroPie/scripts/es_systems_HDDON.cfg ]; then	
	# Backup es_systems.cfg if not exist already
	if [ ! -f ~/RetroPie/scripts/es_systems_HDDON.cfg.b4imp ]; then sudo cp ~/RetroPie/scripts/es_systems_HDDON.cfg ~/RetroPie/scripts/es_systems_HDDON.cfg.b4imp 2>/dev/null; fi
	
	# Replace retropiemenu es_systems.cfg with [IMP]
	sudo sed -i s+'<extension>.rp .sh</extension>'+'<extension>.rp .sh .mp3 .MP3 .pls .PLS .m3u .M3U</extension>'+ ~/RetroPie/scripts/es_systems_HDDON.cfg
	sudo sed -i s+'<command>sudo /home/pi/RetroPie-Setup/retropie_packages.sh retropiemenu launch %ROM% &lt;/dev/tty &gt;/dev/tty</command>'+'<command>bash /opt/retropie/configs/all/retropiemenu.sh %ROM%</command>'+ ~/RetroPie/scripts/es_systems_HDDON.cfg
	sudo sed -i s+'<command>sudo ~/RetroPie-Setup/retropie_packages.sh retropiemenu launch %ROM% &lt;/dev/tty &gt;/dev/tty</command>'+'<command>bash /opt/retropie/configs/all/retropiemenu.sh %ROM%</command>'+ ~/RetroPie/scripts/es_systems_HDDON.cfg
fi

# Copy the MAIN [retropiemenu.sh] Script now called by [retropiemenu] in modified es_systems.cfg
cp main-imp/configs-all/retropiemenu.sh /opt/retropie/configs/all/

# [gamelist.xml] Modifications for retropiemenu OPT
if [ -f /opt/retropie/configs/all/emulationstation/gamelists/retropie/gamelist.xml ]; then	
	# Parse all lines before </gameList>
	cat /opt/retropie/configs/all/emulationstation/gamelists/retropie/gamelist.xml | grep -v "</gameList>" > main-imp/gamelist.h1
	
	# Rebuild retropiemenu gamelist.xml with [IMP]
	cat main-imp/gamelist.h1 > main-imp/gamelist.xml
	cat main-imp/gamelist.imp >> main-imp/gamelist.xml
	
	# Backup es_systems.cfg if not exist already
	if [ ! -f /opt/retropie/configs/all/emulationstation/gamelists/retropie/gamelist.xml.b4imp ]; then sudo mv /opt/retropie/configs/all/emulationstation/gamelists/retropie/gamelist.xml /opt/retropie/configs/all/emulationstation/gamelists/retropie/gamelist.xml.b4imp 2>/dev/null; fi
	
	# Replace retropiemenu gamelist.xml with [IMP]
	cp main-imp/gamelist.xml /opt/retropie/configs/all/emulationstation/gamelists/retropie/gamelist.xml
	
	# Clean up tmp files
	rm main-imp/gamelist.h1
	# rm main-imp/gamelist.imp
	rm main-imp/gamelist.xml
fi

# [gamelist.xml] Modifications for retropiemenu rpMenu
if [ -f ~/RetroPie/retropiemenu/gamelist.xml ]; then	
	# Parse all lines before </gameList>
	cat ~/RetroPie/retropiemenu/gamelist.xml | grep -v "</gameList>" > main-imp/gamelist.h1
	
	# Rebuild retropiemenu gamelist.xml with [IMP]
	cat main-imp/gamelist.h1 > main-imp/gamelist.xml
	cat main-imp/gamelist.imp >> main-imp/gamelist.xml
	
	# Backup es_systems.cfg if not exist already
	if [ ! -f ~/RetroPie/retropiemenu/gamelist.xml.b4imp ]; then sudo mv ~/RetroPie/retropiemenu/gamelist.xml ~/RetroPie/retropiemenu/gamelist.xml.b4imp 2>/dev/null; fi
	
	# Replace retropiemenu gamelist.xml with [IMP]
	cp main-imp/gamelist.xml ~/RetroPie/retropiemenu/gamelist.xml
	
	# Clean up tmp files
	rm main-imp/gamelist.h1
	# rm main-imp/gamelist.imp
	rm main-imp/gamelist.xml
fi

# Copy icon files to retropiemenu
cp main-imp/icons/imp/* ~/RetroPie/retropiemenu/icons/
if [ ! -f ~/RetroPie/retropiemenu/icons/backgroundmusic.png ]; then cp main-imp/icons/imp/impmusicdir.png ~/RetroPie/retropiemenu/icons/backgroundmusic.png; fi
if [ ! -f ~/RetroPie/retropiemenu/icons/jukebox.png ]; then cp main-imp/icons/imp/impmusicdir.png ~/RetroPie/retropiemenu/icons/jukebox.png; fi

# Copy Music to A-SIDE and B-SIDE
if [ ! -f "$musicDIR/bgm/A-SIDE/e1m1.mp3" ]; then mv ~/RetroPie/retropiemenu/icons/impe1m1.png "$musicDIR/bgm/A-SIDE/e1m1.mp3" > /dev/null 2>&1; fi
if [ ! -f "$musicDIR/bgm/B-SIDE/e1m2.mp3" ]; then mv ~/RetroPie/retropiemenu/icons/impe1m2.png "$musicDIR/bgm/B-SIDE/e1m2.mp3" > /dev/null 2>&1; fi

# Install [selectTYPE] autostart.sh runcommand-onstart.sh runcommand-onend.sh
if [ "$selectTYPE" == "$IMPstandard" ]; then
	cp main-imp/standard/autostart.sh /opt/retropie/configs/all/
	cp main-imp/standard/runcommand-onstart.sh /opt/retropie/configs/all/
	cp main-imp/standard/runcommand-onend.sh /opt/retropie/configs/all/
fi

# Install [selectTYPE] autostart.sh runcommand-onstart.sh runcommand-onend.sh
if [ "$selectTYPE" == "$IMPcustom" ]; then
	# MODIFY the Core mpg123 Scripts to be Installed in: /opt/retropie/configs/all/
	cp custom-imp/autostart.sh /opt/retropie/configs/all/
	cp custom-imp/runcommand-onstart.sh /opt/retropie/configs/all/
	cp custom-imp/runcommand-onend.sh /opt/retropie/configs/all/
	
	# 0PTIONAL: Replace [IMP] Menu Scripts that Require Joypad/Keyboard Input to Close
	if [ -f custom-imp/Current\ Playlist.sh ]; then
		rm "$IMPMenuRP/Current Playlist.sh"
		cp custom-imp/Current\ Playlist.sh "$IMPMenuRP/Current Playlist.sh"
	fi
	if [ -f custom-imp/Current\ Settings.sh ]; then
		rm "$IMPMenuRP/Settings/Current Settings.sh"
		cp custom-imp/Current\ Settings.sh "$IMPMenuRP/Settings/Current Settings.sh"
	fi
	if [ -f custom-imp/HTTP\ Server\ Log.sh ]; then
		rm "$IMPMenuRP/Settings/HTTP Server Settings/HTTP Server Log.sh"
		cp custom-imp/HTTP\ Server\ Log.sh "$IMPMenuRP/Settings/HTTP Server Settings/HTTP Server Log.sh"
	fi
	
	# 0PTIONAL Replace Custom Scripts
	if [ -f ~/RetroPie/retropiemenu/attractmode.sh ]; then
		mv ~/RetroPie/retropiemenu/attractmode.sh ~/RetroPie/retropiemenu/attractmode.sh.b4imp
		cp custom-imp/attractmode.sh ~/RetroPie/retropiemenu/
	fi
	if [ -f ~/RetroPie/attractmodemenu/emulationstation.sh ]; then
		mv ~/RetroPie/attractmodemenu/emulationstation.sh ~/RetroPie/attractmodemenu/emulationstation.sh.b4imp
		cp custom-imp/emulationstation.sh ~/RetroPie/attractmodemenu/
	fi
	
	# 0PTIONAL Replace Custom Scripts to be Installed in: /opt/retropie/configs/all/
	if [ -f /opt/retropie/configs/all/ES-start.sh ] && [ -f custom-imp/ES-start.sh ]; then
		mv /opt/retropie/configs/all/ES-start.sh /opt/retropie/configs/all/ES-start.sh.b4imp
		cp custom-imp/ES-start.sh /opt/retropie/configs/all/ES-start.sh
	fi
	if [ -f /opt/retropie/configs/all/Pegasus-start.sh ] && [ -f custom-imp/Pegasus-start.sh ]; then
		mv /opt/retropie/configs/all/Pegasus-start.sh /opt/retropie/configs/all/Pegasus-start.sh.b4imp
		cp custom-imp/Pegasus-start.sh /opt/retropie/configs/all/Pegasus-start.sh
	fi
fi

# Install [selectTYPE] autostart.sh runcommand-onstart.sh runcommand-onend.sh
if [ "$selectTYPE" == "$IMPsupremezero" ]; then	
	# MODIFY the Core mpg123 Scripts to be Installed in: /opt/retropie/configs/all/
	cp main-imp/spz/autostart.sh /opt/retropie/configs/all/
	cp main-imp/spz/runcommand-onstart.sh /opt/retropie/configs/all/
	cp main-imp/spz/runcommand-onend.sh /opt/retropie/configs/all/
	
	# Replace Custom Scripts - attractmode.sh?
	if [ -f ~/RetroPie/retropiemenu/attractmode.sh ]; then
		mv ~/RetroPie/retropiemenu/attractmode.sh ~/RetroPie/retropiemenu/attractmode.sh.b4imp
		cp main-imp/spz/attractmode.sh ~/RetroPie/retropiemenu/
	fi
	if [ -f ~/RetroPie/attractmodemenu/emulationstation.sh ]; then
		mv ~/RetroPie/attractmodemenu/emulationstation.sh ~/RetroPie/attractmodemenu/emulationstation.sh.b4imp
		cp main-imp/spz/emulationstation.sh ~/RetroPie/attractmodemenu/
	fi
	
	# Supreme Build V2 RéGaLaD/WDG (PiZero 20180827) has a bug where RetroPie-Setup does Not have Joypad Support
	# Replace Scripts that Require Joypad/Keyboard Input to Close with Scripts that Auto-Timeout-Close instead
	rm "$IMPMenuRP/Current Playlist.sh"
	rm "$IMPMenuRP/Settings/Current Settings.sh"
	rm "$IMPMenuRP/Settings/HTTP Server Settings/HTTP Server Log.sh"
	cp main-imp/spz/Current\ Playlist.sh "$IMPMenuRP/Current Playlist.sh"
	cp main-imp/spz/Current\ Settings.sh "$IMPMenuRP/Settings/Current Settings.sh"
	cp main-imp/spz/HTTP\ Server\ Log.sh "$IMPMenuRP/Settings/HTTP Server Settings/HTTP Server Log.sh"
fi

# Install [selectTYPE] autostart.sh runcommand-onstart.sh runcommand-onend.sh
if [ "$selectTYPE" == "$IMPsupremepro23b" ]; then	
	# MODIFY the Core mpg123 Scripts to be Installed in: /opt/retropie/configs/all/
	cp main-imp/sp23b/autostart.sh /opt/retropie/configs/all/
	cp main-imp/sp23b/runcommand-onstart.sh /opt/retropie/configs/all/
	cp main-imp/sp23b/runcommand-onend.sh /opt/retropie/configs/all/
	
	# Replace Custom Scripts
	if [ -f ~/RetroPie/retropiemenu/attractmode.sh ]; then
		mv ~/RetroPie/retropiemenu/attractmode.sh ~/RetroPie/retropiemenu/attractmode.sh.b4imp
		cp main-imp/sp23b/attractmode.sh ~/RetroPie/retropiemenu/
	fi
	if [ -f ~/RetroPie/attractmodemenu/emulationstation.sh ]; then
		mv ~/RetroPie/attractmodemenu/emulationstation.sh ~/RetroPie/attractmodemenu/emulationstation.sh.b4imp
		cp main-imp/sp23b/emulationstation.sh ~/RetroPie/attractmodemenu/
	fi
fi

# Install [selectTYPE] autostart.sh runcommand-onstart.sh runcommand-onend.sh
if [ "$selectTYPE" == "$IMPsupremeunified3ab" ]; then
	# MODIFY the Core mpg123 Scripts to be Installed in: /opt/retropie/configs/all/
	cp main-imp/sp3abu/autostart.sh /opt/retropie/configs/all/
	cp main-imp/sp3abu/runcommand-onstart.sh /opt/retropie/configs/all/
	cp main-imp/sp3abu/runcommand-onend.sh /opt/retropie/configs/all/
	
	# Replace Custom Scripts
	if [ -f ~/RetroPie/retropiemenu/attractmode.sh ]; then
		mv ~/RetroPie/retropiemenu/attractmode.sh ~/RetroPie/retropiemenu/attractmode.sh.b4imp
		cp main-imp/sp3abu/attractmode.sh ~/RetroPie/retropiemenu/
	fi
	if [ -f ~/RetroPie/attractmodemenu/emulationstation.sh ]; then
		mv ~/RetroPie/attractmodemenu/emulationstation.sh ~/RetroPie/attractmodemenu/emulationstation.sh.b4imp
		cp main-imp/sp3abu/emulationstation.sh ~/RetroPie/attractmodemenu/
	fi
fi

# Install [selectTYPE] autostart.sh runcommand-onstart.sh runcommand-onend.sh
if [ "$selectTYPE" == "$IMPsupremeduo4" ]; then	
	# MODIFY the Core mpg123 Scripts to be Installed in: /opt/retropie/configs/all/
	cp main-imp/spduo4/autostart.sh /opt/retropie/configs/all/
	cp main-imp/spduo4/runcommand-onstart.sh /opt/retropie/configs/all/
	cp main-imp/spduo4/runcommand-onend.sh /opt/retropie/configs/all/
fi

# Install [selectTYPE] autostart.sh runcommand-onstart.sh runcommand-onend.sh
if [ "$selectTYPE" == "$IMPsupremepro4" ]; then	
	# MODIFY the Core mpg123 Scripts to be Installed in: /opt/retropie/configs/all/
	cp main-imp/sppro4/autostart.sh /opt/retropie/configs/all/
	cp main-imp/sppro4/runcommand-onstart.sh /opt/retropie/configs/all/
	cp main-imp/sppro4/runcommand-onend.sh /opt/retropie/configs/all/
fi

# Install [selectTYPE] autostart.sh runcommand-onstart.sh runcommand-onend.sh
if [ "$selectTYPE" == "$IMPsupremeultrav1" ]; then	
	# MODIFY the Core mpg123 Scripts to be Installed in: /opt/retropie/configs/all/
	cp main-imp/spuv14/autostart.sh /opt/retropie/configs/all/
	cp main-imp/spuv14/runcommand-onstart.sh /opt/retropie/configs/all/
	cp main-imp/spuv14/runcommand-onend.sh /opt/retropie/configs/all/
	
	if [ -f /opt/retropie/configs/all/ES-start.sh ]; then
		mv /opt/retropie/configs/all/ES-start.sh /opt/retropie/configs/all/ES-start.sh.b4imp
		cp main-imp/spuv14/ES-start.sh /opt/retropie/configs/all/
	fi
	
	if [ -f /opt/retropie/configs/all/Pegasus-start.sh ]; then
		mv /opt/retropie/configs/all/Pegasus-start.sh /opt/retropie/configs/all/Pegasus-start.sh.b4imp
		cp main-imp/spuv14/Pegasus-start.sh /opt/retropie/configs/all/
	fi
fi

# Install [selectTYPE] autostart.sh runcommand-onstart.sh runcommand-onend.sh
if [ "$selectTYPE" == "$IMPmbmbttfpp" ]; then
	# MODIFY the Core mpg123 Scripts to be Installed in: /opt/retropie/configs/all/
	cp main-imp/mbmbttf4/autostart.sh /opt/retropie/configs/all/
	cp main-imp/mbmbttf4/runcommand-onstart.sh /opt/retropie/configs/all/
	cp main-imp/mbmbttf4/runcommand-onend.sh /opt/retropie/configs/all/
fi

if [[ ! "$installFLAG" == 'offline' ]]; then
	# Get .M3U from SLAYRadio 202109
	if [ ! -d "$musicDIR/SLAYRadio" ]; then mkdir "$musicDIR/SLAYRadio"; fi
	if [ ! -f "$musicDIR/SLAYRadio/slayradio.128.m3u" ]; then wget --no-check-certificate http://www.slayradio.org/tune_in.php/128kbps/slayradio.128.m3u -P "$musicDIR/SLAYRadio"; fi

	# Copy SLAYRadio icon files to retropiemenu
	cp main-imp/icons/slayradio/slayradio.png ~/RetroPie/retropiemenu/icons/
	cp main-imp/icons/slayradio/slayradio-logo.png ~/RetroPie/retropiemenu/icons/
fi

if [[ ! "$installFLAG" == 'offline' ]]; then
	# Get .PLS from MP3RadioFM 202109
	if [ ! -d "$musicDIR/Mp3RadioFM" ]; then mkdir "$musicDIR/Mp3RadioFM"; fi
	if [ ! -f "$musicDIR/Mp3RadioFM/mp3radio.pls" ]; then wget --no-check-certificate "https://epsilon.shoutca.st/tunein/mp3radio.pls" -P "$musicDIR/Mp3RadioFM"; fi

	# Copy MP3RadioFM icon files to retropiemenu
	cp main-imp/icons/mp3radiofm/mp3radiofm.png ~/RetroPie/retropiemenu/icons/
fi

if [ "$installFLAG" == 'somafm' ]; then
	# Get .PLS from SomaFM 202109
	if [ ! -d "$musicDIR/SomaFM" ]; then mkdir "$musicDIR/SomaFM"; fi
	if [ ! -f "$musicDIR/SomaFM/7soul.pls" ]; then wget --no-check-certificate https://somafm.com/7soul.pls -P "$musicDIR/SomaFM"; fi
	if [ ! -f "$musicDIR/SomaFM/beatblender.pls" ]; then wget --no-check-certificate https://somafm.com/beatblender.pls -P "$musicDIR/SomaFM"; fi
	if [ ! -f "$musicDIR/SomaFM/bootliquor.pls" ]; then wget --no-check-certificate https://somafm.com/bootliquor.pls -P "$musicDIR/SomaFM"; fi
	if [ ! -f "$musicDIR/SomaFM/brfm.pls" ]; then wget --no-check-certificate https://somafm.com/brfm.pls -P "$musicDIR/SomaFM"; fi
	if [ ! -f "$musicDIR/SomaFM/covers.pls" ]; then wget --no-check-certificate https://somafm.com/covers.pls -P "$musicDIR/SomaFM"; fi
	if [ ! -f "$musicDIR/SomaFM/deepspaceone.pls" ]; then wget --no-check-certificate https://somafm.com/deepspaceone.pls -P "$musicDIR/SomaFM"; fi
	if [ ! -f "$musicDIR/SomaFM/digitalis.pls" ]; then wget --no-check-certificate https://somafm.com/digitalis.pls -P "$musicDIR/SomaFM"; fi
	if [ ! -f "$musicDIR/SomaFM/dronezone.pls" ]; then wget --no-check-certificate https://somafm.com/dronezone.pls -P "$musicDIR/SomaFM"; fi
	if [ ! -f "$musicDIR/SomaFM/dubstep.pls" ]; then wget --no-check-certificate https://somafm.com/dubstep.pls -P "$musicDIR/SomaFM"; fi
	if [ ! -f "$musicDIR/SomaFM/fluid.pls" ]; then wget --no-check-certificate https://somafm.com/fluid.pls -P "$musicDIR/SomaFM"; fi
	if [ ! -f "$musicDIR/SomaFM/groovesalad.pls" ]; then wget --no-check-certificate https://somafm.com/groovesalad.pls -P "$musicDIR/SomaFM"; fi
	if [ ! -f "$musicDIR/SomaFM/gsclassic.pls" ]; then wget --no-check-certificate https://somafm.com/gsclassic.pls -P "$musicDIR/SomaFM"; fi
	if [ ! -f "$musicDIR/SomaFM/illstreet.pls" ]; then wget --no-check-certificate https://somafm.com/illstreet.pls -P "$musicDIR/SomaFM"; fi
	if [ ! -f "$musicDIR/SomaFM/indiepop.pls" ]; then wget --no-check-certificate https://somafm.com/indiepop.pls -P "$musicDIR/SomaFM"; fi
	if [ ! -f "$musicDIR/SomaFM/lush.pls" ]; then wget --no-check-certificate https://somafm.com/lush.pls -P "$musicDIR/SomaFM"; fi
	if [ ! -f "$musicDIR/SomaFM/metal.pls" ]; then wget --no-check-certificate https://somafm.com/metal.pls -P "$musicDIR/SomaFM"; fi
	if [ ! -f "$musicDIR/SomaFM/reggae.pls" ]; then wget --no-check-certificate https://somafm.com/reggae.pls -P "$musicDIR/SomaFM"; fi
	if [ ! -f "$musicDIR/SomaFM/secretagent.pls" ]; then wget --no-check-certificate https://somafm.com/secretagent.pls -P "$musicDIR/SomaFM"; fi
	if [ ! -f "$musicDIR/SomaFM/seventies.pls" ]; then wget --no-check-certificate https://somafm.com/seventies.pls -P "$musicDIR/SomaFM"; fi
	if [ ! -f "$musicDIR/SomaFM/sonicuniverse.pls" ]; then wget --no-check-certificate https://somafm.com/sonicuniverse.pls -P "$musicDIR/SomaFM"; fi
	if [ ! -f "$musicDIR/SomaFM/spacestation.pls" ]; then wget --no-check-certificate https://somafm.com/spacestation.pls -P "$musicDIR/SomaFM"; fi
	if [ ! -f "$musicDIR/SomaFM/suburbsofgoa.pls" ]; then wget --no-check-certificate https://somafm.com/suburbsofgoa.pls -P "$musicDIR/SomaFM"; fi
	if [ ! -f "$musicDIR/SomaFM/synphaera.pls" ]; then wget --no-check-certificate https://somafm.com/synphaera.pls -P "$musicDIR/SomaFM"; fi
	if [ ! -f "$musicDIR/SomaFM/thetrip.pls" ]; then wget --no-check-certificate https://somafm.com/thetrip.pls -P "$musicDIR/SomaFM"; fi
	if [ ! -f "$musicDIR/SomaFM/thistle.pls" ]; then wget --no-check-certificate https://somafm.com/thistle.pls -P "$musicDIR/SomaFM"; fi
	if [ ! -f "$musicDIR/SomaFM/u80s.pls" ]; then wget --no-check-certificate https://somafm.com/u80s.pls -P "$musicDIR/SomaFM"; fi
	if [ ! -f "$musicDIR/SomaFM/vaporwaves.pls" ]; then wget --no-check-certificate https://somafm.com/vaporwaves.pls -P "$musicDIR/SomaFM"; fi
	# Seasonal SomaFM
	if [ ! -f "$musicDIR/SomaFM/christmas.pls" ]; then wget --no-check-certificate https://somafm.com/christmas.pls -P "$musicDIR/SomaFM"; fi
	if [ ! -f "$musicDIR/SomaFM/xmasrocks.pls" ]; then wget --no-check-certificate https://somafm.com/xmasrocks.pls -P "$musicDIR/SomaFM"; fi
	if [ ! -f "$musicDIR/SomaFM/jollysoul.pls" ]; then wget --no-check-certificate https://somafm.com/jollysoul.pls -P "$musicDIR/SomaFM"; fi
	if [ ! -f "$musicDIR/SomaFM/xmasinfrisko.pls" ]; then wget --no-check-certificate https://somafm.com/xmasinfrisko.pls -P "$musicDIR/SomaFM"; fi
	if [ ! -f "$musicDIR/SomaFM/specials.pls" ]; then wget --no-check-certificate https://somafm.com/specials.pls -P "$musicDIR/SomaFM"; fi
	
	# Copy SomaFM icon files to retropiemenu
	cp main-imp/icons/somafm/*.png ~/RetroPie/retropiemenu/icons/
	cp main-imp/icons/somafm/*.jpg ~/RetroPie/retropiemenu/icons/
fi

impFINISH
}

impUNINSTALL()
{
tput reset

# Check if IMP Installed
if [ ! -d "$IMP" ]; then
	dialog --no-collapse --title "   * [IMP] INSTALL NOT DETECTED *   " --ok-label Back --msgbox "$impLOGO $impFILEREF"  25 75
	mainMENU
fi

# Stop [IMP]
bash $IMP/stop.sh
pkill -KILL mpg123

# Uninstall mpg123
# sudo apt-get -y remove mpg123

# Turn Off HTTP Server - Cleans up $HTTPFolder/favicon.ico
bash "$IMPMenuRP/Settings/HTTP Server Settings/HTTP Server [Off].sh"

# Restore autostart.sh if Backup is found
if [ -f /opt/retropie/configs/all/autostart.sh.b4imp ]; then
    mv /opt/retropie/configs/all/autostart.sh.b4imp /opt/retropie/configs/all/autostart.sh
else
	# Create autostart.sh from scratch if Backup NOT found
	echo "emulationstation #auto" > /opt/retropie/configs/all/autostart.sh
fi

# Restore runcommand-onstart.sh if Backup is found
if [ -f /opt/retropie/configs/all/runcommand-onstart.sh.b4imp ]; then
    mv /opt/retropie/configs/all/runcommand-onstart.sh.b4imp /opt/retropie/configs/all/runcommand-onstart.sh
else
    # Remove runcommand-onstart.sh if Backup NOT found
	rm /opt/retropie/configs/all/runcommand-onstart.sh
fi

# Restore runcommand-onend.sh if Backup is found
if [ -f /opt/retropie/configs/all/runcommand-onend.sh.b4imp ]; then
    mv /opt/retropie/configs/all/runcommand-onend.sh.b4imp /opt/retropie/configs/all/runcommand-onend.sh
else
    # Remove runcommand-onend.sh if Backup NOT found
	rm /opt/retropie/configs/all/runcommand-onend.sh
fi

# Restore gamelist.xml OPT if Backup is found
if [ -f /opt/retropie/configs/all/emulationstation/gamelists/retropie/gamelist.xml.b4imp ]; then
    mv /opt/retropie/configs/all/emulationstation/gamelists/retropie/gamelist.xml.b4imp /opt/retropie/configs/all/emulationstation/gamelists/retropie/gamelist.xml
fi

# Restore gamelist.xml retropiemenu if Backup is found
if [ -f ~/RetroPie/retropiemenu/gamelist.xml.b4imp ]; then
    mv ~/RetroPie/retropiemenu/gamelist.xml.b4imp ~/RetroPie/retropiemenu/gamelist.xml
fi

# Restore es_systems.cfg if Backup is found ETC
if [ -f /etc/emulationstation/es_systems.cfg.b4imp ]; then
    sudo mv /etc/emulationstation/es_systems.cfg.b4imp /etc/emulationstation/es_systems.cfg
fi

# Restore es_systems.cfg if Backup is found OPT
if [ -f /opt/retropie/configs/all/emulationstation/es_systems.cfg.b4imp ]; then
    sudo mv /opt/retropie/configs/all/emulationstation/es_systems.cfg.b4imp /opt/retropie/configs/all/emulationstation/es_systems.cfg
fi

# Restore es_systems.cfg if Backup is found HDDON/HDDOFF BAK
if [ -f /opt/retropie/configs/all/emulationstation/es_systems.cfg.bk.b4imp ]; then
    sudo mv /opt/retropie/configs/all/emulationstation/es_systems.cfg.bk.b4imp /opt/retropie/configs/all/emulationstation/es_systems.cfg.bk
fi

# Restore es_systems.cfg if Backup is found HDDOFF
if [ -f ~/RetroPie/scripts/es_systems_HDDOFF.cfg.b4imp ]; then
    sudo mv ~/RetroPie/scripts/es_systems_HDDOFF.cfg.b4imp ~/RetroPie/scripts/es_systems_HDDOFF.cfg
fi

# Restore es_systems.cfg if Backup is found HDDON
if [ -f ~/RetroPie/scripts/es_systems_HDDON.cfg.b4imp ]; then
    sudo mv ~/RetroPie/scripts/es_systems_HDDON.cfg.b4imp ~/RetroPie/scripts/es_systems_HDDON.cfg
fi

# Restore 0ther Custom Scripts
if [ -f ~/RetroPie/retropiemenu/attractmode.sh.b4imp ]; then mv ~/RetroPie/retropiemenu/attractmode.sh.b4imp ~/RetroPie/retropiemenu/attractmode.sh; fi
if [ -f ~/RetroPie/attractmodemenu/emulationstation.sh.b4imp ]; then mv ~/RetroPie/attractmodemenu/emulationstation.sh.b4imp ~/RetroPie/attractmodemenu/emulationstation.sh; fi
if [ -f /opt/retropie/configs/all/ES-start.sh.b4imp ]; then mv /opt/retropie/configs/all/ES-start.sh.b4imp /opt/retropie/configs/all/ES-start.sh; fi
if [ -f /opt/retropie/configs/all/Pegasus-start.sh.b4imp ]; then mv /opt/retropie/configs/all/Pegasus-start.sh.b4imp /opt/retropie/configs/all/Pegasus-start.sh; fi

# Remove the [retropiemenu.sh] Script Associated with es_systems.cfg
rm /opt/retropie/configs/all/retropiemenu.sh

# Restore [.bashrc]
if [ -f ~/.bashrc.b4imp ]; then mv ~/.bashrc.b4imp ~/.bashrc; fi

# Remove symbolic link to music from retropiemenu
unlink $musicROMS
mv $musicDIR $musicROMS

# Remove [IMP] files from retropiemenu
rm $IMPMenuRP/*.sh
rm $IMPMenuRP/Settings/*.sh
rm $IMPMenuRP/Settings/BGM\ Settings/*.sh
rm $IMPMenuRP/Settings/Game\ Settings/*.sh
rm $IMPMenuRP/Settings/HTTP\ Server\ Settings/*.sh
rm $IMPMenuRP/Settings/Startup\ Settings/*.sh
rm $IMPMenuRP/Volume/*.sh

# Remove [IMP] Directories from retropiemenu
# rm -R $IMPMenuRP
rm -d $IMPMenuRP/Settings/BGM\ Settings/
rm -d $IMPMenuRP/Settings/Game\ Settings/
rm -d $IMPMenuRP/Settings/HTTP\ Server\ Settings/
rm -d $IMPMenuRP/Settings/Startup\ Settings/
rm -d $IMPMenuRP/Settings/
rm -d $IMPMenuRP/Volume/
rm -d $IMPMenuRP/

# Remove [IMP] files from /opt/retropie/configs/all
rm $IMP/playlist/* 2>/dev/null
rm $IMP/settings/* 2>/dev/null
rm $IMP/* 2>/dev/null

# Remove [IMP] Directories from /opt/retropie/configs/all
# rm -R $IMP
rm -d $IMP/playlist/ 2>/dev/null
rm -d $IMP/settings/ 2>/dev/null
rm -d $IMP/ 2>/dev/null

# Remove [IMP] Icons from retropiemenu
rm ~/RetroPie/retropiemenu/icons/e1m1.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/e1m2.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/imp.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impbgmdira.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impbgmdirb.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impbgmdirs.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impe1m1.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impe1m2.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/imphttplog.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/imphttpon.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/imphttpoff.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impinfiniteoff.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impinfiniteon.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impmusicdir.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impnext.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/imppause.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impplay.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impplaylist.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impprevious.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impprevious0ff.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impprevious0n.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impsettingadjust.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impsettingbgmaoff.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impsettingbgmaon.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impsettingbgmboff.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impsettingbgmbon.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impsettingfadeoff.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impsettingfadeon.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impsettingmusicoff.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impsettingmusicon.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impsettingoff.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impsettingon.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impsettings.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impsettingscurrent.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impshuffleoff.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impshuffleon.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impstartall.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impstartbgm.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impstop.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impvolume.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impvolume05.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impvolume10.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impvolume20.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impvolume30.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impvolume40.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impvolume50.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impvolume60.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impvolume70.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impvolume80.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impvolume90.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/impvolume100.png 2>/dev/null

# Remove SomaFM
rm $musicROMS/SomaFM/*.pls 2>/dev/null
rm -d $musicROMS/SomaFM 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/somafm.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/7soul-400.jpg 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/beatblender-400.jpg 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/bootliquor-400.jpg 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/brfm-400.jpg 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/covers-400.jpg 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/deepspaceone-400.jpg 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/digitalis-400.jpg 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/dronezone-400.jpg 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/dubstep-400.jpg 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/fluid-400.jpg 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/groovesalad-400.jpg 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/gsclassic400.jpg 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/illstreet-400.jpg 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/indiepop-400.jpg 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/lush-400.jpg 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/metal-400.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/reggae400.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/secretagent-400.jpg 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/seventies400.jpg 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/sonicuniverse-400.jpg 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/spacestation-400.jpg 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/suburbsofgoa-400.jpg 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/synphaera400.jpg 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/thetrip-400.jpg 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/thistle-400.jpg 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/u80s-400.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/vaporwaves-400.jpg 2>/dev/null
# Seasonal SomaFM
rm ~/RetroPie/retropiemenu/icons/christmas-400.jpg 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/jollysoul-400.jpg 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/xmasinfrisko-400.jpg 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/xmasrocks-400.jpg 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/specials-400.jpg 2>/dev/null

# Remove SLAYRadio
rm $musicROMS/SLAYRadio/*.m3u 2>/dev/null
rm -d $musicROMS/SLAYRadio 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/slayradio.png 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/slayradio-logo.png 2>/dev/null

# Remove MP3RadioFM
rm $musicROMS/Mp3RadioFM/*.pls 2>/dev/null
rm -d $musicROMS/Mp3RadioFM 2>/dev/null
rm ~/RetroPie/retropiemenu/icons/mp3radiofm.png 2>/dev/null

# Clean up Symbolic Links
if [ -d "$musicROMS/_bgm" ]; then rm "$musicROMS/_bgm"; fi
if [ -d "$musicROMS/_backgroundmusic" ]; then rm "$musicROMS/_backgroundmusic"; fi
if [ -d "$musicROMS/_jukebox_mp3" ]; then rm "$musicROMS/_jukebox_mp3"; fi
# if [ -d "$musicROMS/_AttractModeSounds" ]; then rm "$musicROMS/_AttractModeSounds"; fi

# Enable 0ther BGMs Indiscriminately
# Restore Various backgroundmusic scripts
if [ -f ~/RetroPie/retropiemenu/backgroundmusic.sh.b4imp ]; then mv ~/RetroPie/retropiemenu/backgroundmusic.sh.b4imp ~/RetroPie/retropiemenu/backgroundmusic.sh; fi
if [ -f ~/RetroPie/retropiemenu/Audiotools/backgroundmusic.sh.b4imp ]; then mv ~/RetroPie/retropiemenu/Audiotools/backgroundmusic.sh.b4imp ~/RetroPie/retropiemenu/Audiotools/backgroundmusic.sh; fi
if [ -f ~/RetroPie/retropiemenu/audiotools/backgroundmusic.sh.b4imp ]; then mv ~/RetroPie/retropiemenu/audiotools/backgroundmusic.sh.b4imp ~/RetroPie/retropiemenu/audiotools/backgroundmusic.sh; fi

# Enable Livewire
if [ -f ~/.DisableMusic ]; then rm ~/.DisableMusic; fi

# Enable BGM Naprosnia
# if [ -f ~/RetroPie/retropiemenu/Audiotools/backgroundmusic.sh.b4imp ]; then mv ~/RetroPie/retropiemenu/Audiotools/backgroundmusic.sh.b4imp ~/RetroPie/retropiemenu/Audiotools/backgroundmusic.sh 2>/dev/null; fi
if [ -f ~/RetroPie/retropiemenu/RetroPie-BGM-Player.sh.b4imp ]; then mv ~/RetroPie/retropiemenu/RetroPie-BGM-Player.sh.b4imp ~/RetroPie/retropiemenu/RetroPie-BGM-Player.sh 2>/dev/null; fi
if [ -f ~/RetroPie-BGM-Player/bgm_system.sh ]; then
	bash ~/RetroPie-BGM-Player/bgm_system.sh -setsetting bgm_toggle 1
	bash ~/RetroPie-BGM-Player/bgm_system.sh -i
fi

# Enable BGM Rydra
sudo systemctl enable bgm > /dev/null 2>&1
sudo systemctl start bgm > /dev/null 2>&1
# sudo systemctl daemon-reload > /dev/null 2>&1

# Enable BGM 0fficialPhilcomm
sudo systemctl enable retropie_music > /dev/null 2>&1
sudo systemctl start retropie_music > /dev/null 2>&1
# sudo systemctl daemon-reload > /dev/null 2>&1

# Final daemon-reload after Enable 0ther BGMs
sudo systemctl daemon-reload > /dev/null 2>&1

impFINISH
}

impFINISH()
{
# Finished Install - Confirm Reboot
confREBOOT=$(dialog --stdout --no-collapse --title "*INSTALL* $selectTYPE *COMPLETE*" \
	--ok-label OK --cancel-label EXIT \
	--menu "$impLOGO $impFINISHREF" 25 75 20 \
	1 "REBOOT" \
	2 "EXIT")
# Reboot Confirm - Otherwise Exit
if [ "$confREBOOT" == '1' ]; then tput reset && sudo reboot; fi

tput reset
exit 0
}

# DISCLAIMER
tput reset
dialog --no-collapse --title "   *DISCLAIMER* Install [IMP] at your own Risk   " --ok-label CONTINUE --msgbox "$impLOGO $impFILEREF"  25 75

mainMENU

tput reset
exit 0
